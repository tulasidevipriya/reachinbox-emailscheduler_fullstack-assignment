import { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import {
  CalendarClock,
  CheckCircle2,
  ChevronDown,
  LogOut,
  Mail,
  Plus,
  Send,
  XCircle,
} from "lucide-react";
import { format } from "date-fns";

import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

type User = {
  name: string;
  email: string;
  avatarUrl: string;
};

type EmailStatus = "scheduled" | "sent" | "failed";

type EmailRecord = {
  id: string;
  to: string;
  subject: string;
  scheduledAt: number;
  sentAt?: number;
  status: EmailStatus;
};

function loadUser(): User | null {
  try {
    const raw = localStorage.getItem("reachinbox_user");
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function safeParseEmails(text: string): string[] {
  const normalized = text
    .replace(/\r/g, "\n")
    .replace(/\n+/g, "\n")
    .trim();

  const parts = normalized
    .split(/[,;\n\t\s]+/)
    .map((s) => s.trim())
    .filter(Boolean);

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const unique = new Set<string>();
  for (const p of parts) {
    if (emailRegex.test(p)) unique.add(p.toLowerCase());
  }
  return Array.from(unique);
}

function makeId() {
  return Math.random().toString(16).slice(2) + Date.now().toString(16);
}

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const [user, setUser] = useState<User | null>(null);

  const [activeTab, setActiveTab] = useState<"scheduled" | "sent">("scheduled");
  const [composeOpen, setComposeOpen] = useState(false);

  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [leadsText, setLeadsText] = useState("");
  const [startTime, setStartTime] = useState<string>(() => {
    const d = new Date(Date.now() + 10 * 60 * 1000);
    const pad = (n: number) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  });
  const [delayBetween, setDelayBetween] = useState("2");
  const [hourlyLimit, setHourlyLimit] = useState("200");

  const [items, setItems] = useState<EmailRecord[]>(() => {
    const now = Date.now();
    return [
      {
        id: "seed-1",
        to: "jules@acme.io",
        subject: "Quick intro from ReachInbox",
        scheduledAt: now + 45 * 60 * 1000,
        status: "scheduled",
      },
      {
        id: "seed-2",
        to: "dana@studio.com",
        subject: "Your campaign is ready",
        scheduledAt: now - 2 * 60 * 60 * 1000,
        sentAt: now - 1 * 60 * 60 * 58 * 1000,
        status: "sent",
      },
      {
        id: "seed-3",
        to: "ops@northwind.org",
        subject: "Delivery report (sample)",
        scheduledAt: now - 26 * 60 * 60 * 1000,
        sentAt: now - 26 * 60 * 60 * 1000 + 3 * 60 * 1000,
        status: "failed",
      },
    ];
  });

  useEffect(() => {
    const u = loadUser();
    if (!u) {
      setLocation("/login");
      return;
    }
    setUser(u);
  }, [setLocation]);

  const scheduled = useMemo(
    () => items.filter((i) => i.status === "scheduled").sort((a, b) => a.scheduledAt - b.scheduledAt),
    [items],
  );

  const sent = useMemo(
    () => items.filter((i) => i.status !== "scheduled").sort((a, b) => (b.sentAt ?? 0) - (a.sentAt ?? 0)),
    [items],
  );

  const parsedLeadEmails = useMemo(() => safeParseEmails(leadsText), [leadsText]);

  function logout() {
    localStorage.removeItem("reachinbox_user");
    setLocation("/login");
  }

  function onUpload(file: File) {
    const reader = new FileReader();
    reader.onload = () => {
      const text = String(reader.result ?? "");
      setLeadsText(text);
      toast.success(`Imported ${safeParseEmails(text).length} emails`);
    };
    reader.readAsText(file);
  }

  function schedule() {
    if (!subject.trim()) {
      toast.error("Please add a subject");
      return;
    }
    if (!body.trim()) {
      toast.error("Please add an email body");
      return;
    }
    if (parsedLeadEmails.length === 0) {
      toast.error("Upload or paste leads with valid emails");
      return;
    }

    const start = new Date(startTime).getTime();
    if (!Number.isFinite(start)) {
      toast.error("Please choose a valid start time");
      return;
    }

    const delaySec = Math.max(0, Number(delayBetween || 0));

    const newItems: EmailRecord[] = parsedLeadEmails.map((to, idx) => ({
      id: makeId() + `-${idx}`,
      to,
      subject: subject.trim(),
      scheduledAt: start + idx * delaySec * 1000,
      status: "scheduled",
    }));

    setItems((prev) => [...newItems, ...prev]);
    setComposeOpen(false);
    toast.success(`Scheduled ${newItems.length} emails`);

    setActiveTab("scheduled");
  }

  if (!user) return null;

  return (
    <div className="min-h-dvh bg-background" data-testid="page-dashboard">
      <div className="mx-auto w-full max-w-6xl px-6 py-8">
        <header className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-3">
            <div className="relative h-11 w-11 overflow-hidden rounded-xl border bg-card">
              <img
                src={user.avatarUrl}
                alt={user.name}
                className="h-full w-full object-cover"
                data-testid="img-user-avatar"
              />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h1 className="truncate text-xl font-semibold" data-testid="text-user-name">
                  {user.name}
                </h1>
                <Badge variant="secondary" className="hidden sm:inline-flex" data-testid="badge-user-plan">
                  Prototype
                </Badge>
              </div>
              <p className="truncate text-sm text-muted-foreground" data-testid="text-user-email">
                {user.email}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="secondary"
              className="h-10"
              onClick={() => setComposeOpen(true)}
              data-testid="button-compose"
            >
              <Plus className="mr-2 h-4 w-4" />
              Compose New Email
            </Button>

            <Button
              variant="ghost"
              className="h-10"
              onClick={logout}
              data-testid="button-logout"
            >
              <LogOut className="mr-2 h-4 w-4" />
              Logout
            </Button>
          </div>
        </header>

        <div className="mt-7 grid grid-cols-1 gap-4 md:grid-cols-3">
          <Card className="glass shadow-soft border-0 p-4 app-noise" data-testid="card-metric-scheduled">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground" data-testid="text-metric-scheduled-label">
                  Scheduled
                </p>
                <p className="mt-1 text-2xl font-semibold" data-testid="text-metric-scheduled-value">
                  {scheduled.length}
                </p>
              </div>
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-[hsl(var(--primary)/0.12)] text-[hsl(var(--primary))]">
                <CalendarClock className="h-5 w-5" />
              </div>
            </div>
          </Card>

          <Card className="glass shadow-soft border-0 p-4 app-noise" data-testid="card-metric-sent">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground" data-testid="text-metric-sent-label">
                  Sent
                </p>
                <p className="mt-1 text-2xl font-semibold" data-testid="text-metric-sent-value">
                  {sent.filter((s) => s.status === "sent").length}
                </p>
              </div>
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-[hsl(var(--accent)/0.14)] text-[hsl(var(--accent))]">
                <Send className="h-5 w-5" />
              </div>
            </div>
          </Card>

          <Card className="glass shadow-soft border-0 p-4 app-noise" data-testid="card-metric-failed">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground" data-testid="text-metric-failed-label">
                  Failed
                </p>
                <p className="mt-1 text-2xl font-semibold" data-testid="text-metric-failed-value">
                  {sent.filter((s) => s.status === "failed").length}
                </p>
              </div>
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-[hsl(var(--destructive)/0.12)] text-[hsl(var(--destructive))]">
                <XCircle className="h-5 w-5" />
              </div>
            </div>
          </Card>
        </div>

        <div className="mt-6">
          <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)} data-testid="tabs-emails">
            <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
              <div>
                <h2 className="text-lg font-semibold" data-testid="text-dashboard-title">
                  Email Jobs
                </h2>
                <p className="text-sm text-muted-foreground" data-testid="text-dashboard-subtitle">
                  Monitor scheduled jobs and delivery results.
                </p>
              </div>

              <TabsList className="w-full justify-start md:w-auto" data-testid="tabslist-emails">
                <TabsTrigger value="scheduled" data-testid="tab-scheduled">
                  Scheduled
                </TabsTrigger>
                <TabsTrigger value="sent" data-testid="tab-sent">
                  Sent
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="scheduled" className="mt-4" data-testid="tabcontent-scheduled">
              <Card className="glass shadow-soft border-0 p-0 app-noise" data-testid="card-scheduled-table">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[34%]" data-testid="th-email">
                        Email
                      </TableHead>
                      <TableHead data-testid="th-subject">Subject</TableHead>
                      <TableHead className="w-[22%]" data-testid="th-scheduled-time">
                        Scheduled time
                      </TableHead>
                      <TableHead className="w-[12%]" data-testid="th-status">
                        Status
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {scheduled.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={4} className="py-10 text-center text-sm text-muted-foreground" data-testid="empty-scheduled">
                          No scheduled emails yet. Compose a new one to get started.
                        </TableCell>
                      </TableRow>
                    ) : (
                      scheduled.map((r) => (
                        <TableRow key={r.id} data-testid={`row-scheduled-${r.id}`}>
                          <TableCell className="font-medium" data-testid={`text-email-${r.id}`}>
                            <div className="flex items-center gap-2">
                              <span className="grid h-8 w-8 place-items-center rounded-lg bg-[hsl(var(--primary)/0.10)] text-[hsl(var(--primary))]">
                                <Mail className="h-4 w-4" />
                              </span>
                              <span className="truncate">{r.to}</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-muted-foreground" data-testid={`text-subject-${r.id}`}>
                            <span className="line-clamp-1">{r.subject}</span>
                          </TableCell>
                          <TableCell className="text-muted-foreground" data-testid={`text-scheduledat-${r.id}`}>
                            {format(new Date(r.scheduledAt), "MMM d, yyyy \u00b7 HH:mm")}
                          </TableCell>
                          <TableCell data-testid={`status-${r.id}`}>
                            <Badge className="bg-[hsl(var(--primary)/0.10)] text-[hsl(var(--primary))] hover:bg-[hsl(var(--primary)/0.16)]">
                              scheduled
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </Card>
            </TabsContent>

            <TabsContent value="sent" className="mt-4" data-testid="tabcontent-sent">
              <Card className="glass shadow-soft border-0 p-0 app-noise" data-testid="card-sent-table">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[34%]" data-testid="th-email-sent">
                        Email
                      </TableHead>
                      <TableHead data-testid="th-subject-sent">Subject</TableHead>
                      <TableHead className="w-[22%]" data-testid="th-sent-time">
                        Sent time
                      </TableHead>
                      <TableHead className="w-[12%]" data-testid="th-status-sent">
                        Status
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sent.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={4} className="py-10 text-center text-sm text-muted-foreground" data-testid="empty-sent">
                          No sent emails yet.
                        </TableCell>
                      </TableRow>
                    ) : (
                      sent.map((r) => (
                        <TableRow key={r.id} data-testid={`row-sent-${r.id}`}>
                          <TableCell className="font-medium" data-testid={`text-email-sent-${r.id}`}>
                            <div className="flex items-center gap-2">
                              <span className="grid h-8 w-8 place-items-center rounded-lg bg-[hsl(var(--secondary))] text-foreground">
                                <Mail className="h-4 w-4" />
                              </span>
                              <span className="truncate">{r.to}</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-muted-foreground" data-testid={`text-subject-sent-${r.id}`}>
                            <span className="line-clamp-1">{r.subject}</span>
                          </TableCell>
                          <TableCell className="text-muted-foreground" data-testid={`text-sentat-${r.id}`}>
                            {r.sentAt ? format(new Date(r.sentAt), "MMM d, yyyy \u00b7 HH:mm") : "\u2014"}
                          </TableCell>
                          <TableCell data-testid={`status-sent-${r.id}`}>
                            {r.status === "sent" ? (
                              <Badge className="bg-emerald-500/12 text-emerald-600 hover:bg-emerald-500/16">
                                <CheckCircle2 className="mr-1 h-3.5 w-3.5" />
                                sent
                              </Badge>
                            ) : (
                              <Badge className="bg-red-500/12 text-red-600 hover:bg-red-500/16">
                                <XCircle className="mr-1 h-3.5 w-3.5" />
                                failed
                              </Badge>
                            )}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      <Dialog open={composeOpen} onOpenChange={setComposeOpen}>
        <DialogContent className="max-w-2xl" data-testid="modal-compose">
          <DialogHeader>
            <DialogTitle data-testid="text-compose-title">Compose New Email</DialogTitle>
          </DialogHeader>

          <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="subject" data-testid="label-subject">Subject</Label>
                <Input
                  id="subject"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Subject line"
                  data-testid="input-subject"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="body" data-testid="label-body">Body</Label>
                <Textarea
                  id="body"
                  value={body}
                  onChange={(e) => setBody(e.target.value)}
                  placeholder="Write your email body..."
                  className="min-h-32"
                  data-testid="textarea-body"
                />
              </div>

              <div className="space-y-2">
                <Label data-testid="label-leads">Leads (CSV or text)</Label>
                <div className="flex flex-col gap-2">
                  <Textarea
                    value={leadsText}
                    onChange={(e) => setLeadsText(e.target.value)}
                    placeholder="Paste emails here (comma, space, or newline separated)"
                    className="min-h-28"
                    data-testid="textarea-leads"
                  />
                  <div className="flex items-center justify-between">
                    <p className="text-xs text-muted-foreground" data-testid="text-leads-count">
                      Detected: <span className="font-medium text-foreground">{parsedLeadEmails.length}</span>
                    </p>
                    <label className="inline-flex cursor-pointer items-center gap-2 rounded-md border bg-card px-3 py-2 text-xs hover:bg-muted/50" data-testid="button-upload">
                      <input
                        type="file"
                        accept=".csv,.txt"
                        className="hidden"
                        onChange={(e) => {
                          const f = e.target.files?.[0];
                          if (f) onUpload(f);
                        }}
                        data-testid="input-file"
                      />
                      <ChevronDown className="h-4 w-4" />
                      Upload file
                    </label>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <Card className="glass shadow-soft border-0 p-4 app-noise" data-testid="card-schedule-settings">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="start" data-testid="label-start">Start time</Label>
                    <Input
                      id="start"
                      type="datetime-local"
                      value={startTime}
                      onChange={(e) => setStartTime(e.target.value)}
                      data-testid="input-starttime"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="delay" data-testid="label-delay">Delay between</Label>
                      <div className="relative">
                        <Input
                          id="delay"
                          inputMode="numeric"
                          value={delayBetween}
                          onChange={(e) => setDelayBetween(e.target.value.replace(/[^0-9.]/g, ""))}
                          data-testid="input-delay"
                        />
                        <span className="pointer-events-none absolute inset-y-0 right-3 grid place-items-center text-xs text-muted-foreground">
                          sec
                        </span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="limit" data-testid="label-hourly">Hourly limit</Label>
                      <Input
                        id="limit"
                        inputMode="numeric"
                        value={hourlyLimit}
                        onChange={(e) => setHourlyLimit(e.target.value.replace(/[^0-9]/g, ""))}
                        data-testid="input-hourly"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label data-testid="label-sender">Sender</Label>
                    <Select defaultValue="ethereal-1">
                      <SelectTrigger data-testid="select-sender">
                        <SelectValue placeholder="Choose sender" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ethereal-1">Ethereal Sender 1</SelectItem>
                        <SelectItem value="ethereal-2">Ethereal Sender 2</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="rounded-lg border bg-background/50 p-3 text-xs text-muted-foreground" data-testid="text-schedule-note">
                    These settings are preview-only in this prototype. In the full app, they\u2019d be enforced by the job worker.
                  </div>
                </div>
              </Card>

              <div className="flex items-center justify-end gap-2">
                <Button
                  variant="secondary"
                  onClick={() => setComposeOpen(false)}
                  data-testid="button-cancel"
                >
                  Cancel
                </Button>
                <Button onClick={schedule} data-testid="button-schedule">
                  Schedule
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
