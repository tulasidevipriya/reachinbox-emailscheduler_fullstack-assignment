import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Mail, ShieldCheck, Sparkles } from "lucide-react";

const mockUser = {
  name: "Avery Chen",
  email: "avery.chen@reachinbox.dev",
  avatarUrl: "https://api.dicebear.com/7.x/notionists/svg?seed=reachinbox",
};

export default function Login() {
  const [, setLocation] = useLocation();

  return (
    <div
      className="min-h-dvh bg-background"
      data-testid="page-login"
    >
      <div className="relative overflow-hidden">
        <div
          className="pointer-events-none absolute inset-0"
          aria-hidden
        >
          <div className="absolute -top-36 left-1/2 h-[520px] w-[520px] -translate-x-1/2 rounded-full bg-[radial-gradient(circle_at_center,hsl(var(--accent)/0.20),transparent_60%)] blur-2xl" />
          <div className="absolute -bottom-56 left-0 h-[520px] w-[520px] rounded-full bg-[radial-gradient(circle_at_center,hsl(var(--primary)/0.18),transparent_60%)] blur-2xl" />
          <div className="absolute right-0 top-32 h-[420px] w-[420px] rounded-full bg-[radial-gradient(circle_at_center,hsl(var(--primary)/0.12),transparent_60%)] blur-2xl" />
        </div>

        <div className="mx-auto flex min-h-dvh w-full max-w-6xl items-center px-6 py-12">
          <div className="grid w-full grid-cols-1 items-center gap-10 lg:grid-cols-2">
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: [0.21, 0.61, 0.35, 1] }}
              className="space-y-6"
            >
              <div className="inline-flex items-center gap-2 rounded-full border bg-card/50 px-3 py-1 text-xs text-muted-foreground app-noise">
                <Sparkles className="h-3.5 w-3.5 text-[hsl(var(--accent))]" />
                <span data-testid="text-login-badge">Production-grade scheduling UI</span>
              </div>

              <div className="space-y-3">
                <h1
                  className="text-balance text-4xl font-semibold leading-[1.05] tracking-[-0.04em] md:text-5xl"
                  data-testid="text-login-title"
                >
                  ReachInbox Email Scheduler
                </h1>
                <p
                  className="max-w-xl text-pretty text-base leading-relaxed text-muted-foreground md:text-lg"
                  data-testid="text-login-subtitle"
                >
                  Schedule campaigns, throttle delivery, and track sends \u2014 all from a clean dashboard.
                </p>
              </div>

              <div className="grid max-w-xl grid-cols-1 gap-3 sm:grid-cols-2">
                <div className="glass shadow-soft rounded-xl p-4 app-noise">
                  <div className="flex items-start gap-3">
                    <div className="grid h-9 w-9 place-items-center rounded-lg bg-[hsl(var(--primary)/0.12)] text-[hsl(var(--primary))]">
                      <Mail className="h-4.5 w-4.5" />
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium" data-testid="text-login-feature-1-title">
                        Compose & schedule
                      </p>
                      <p className="text-xs text-muted-foreground" data-testid="text-login-feature-1-desc">
                        Queue 1000+ sends without sweating.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="glass shadow-soft rounded-xl p-4 app-noise">
                  <div className="flex items-start gap-3">
                    <div className="grid h-9 w-9 place-items-center rounded-lg bg-[hsl(var(--accent)/0.14)] text-[hsl(var(--accent))]">
                      <ShieldCheck className="h-4.5 w-4.5" />
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium" data-testid="text-login-feature-2-title">
                        Safe throttling
                      </p>
                      <p className="text-xs text-muted-foreground" data-testid="text-login-feature-2-desc">
                        Hourly limits & per-email delays.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65, delay: 0.05, ease: [0.21, 0.61, 0.35, 1] }}
              className="flex items-center justify-center"
            >
              <Card className="glass shadow-soft w-full max-w-md border-0 p-6 app-noise">
                <div className="space-y-5">
                  <div className="space-y-2">
                    <h2 className="text-xl font-semibold" data-testid="text-login-card-title">
                      Continue with Google
                    </h2>
                    <p className="text-sm text-muted-foreground" data-testid="text-login-card-subtitle">
                      In this prototype, we\u2019ll simulate Google login and take you to the dashboard.
                    </p>
                  </div>

                  <Button
                    className="h-11 w-full"
                    data-testid="button-login-google"
                    onClick={() => {
                      localStorage.setItem("reachinbox_user", JSON.stringify(mockUser));
                      setLocation("/dashboard");
                    }}
                  >
                    Sign in with Google
                  </Button>

                  <div className="rounded-lg border bg-background/50 p-3 text-xs text-muted-foreground">
                    <p data-testid="text-login-note">
                      This is UI-only mock data. Hooking up real OAuth requires a backend integration.
                    </p>
                  </div>
                </div>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
